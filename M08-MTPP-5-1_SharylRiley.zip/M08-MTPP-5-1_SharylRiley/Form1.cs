﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M08_MTPP_5_1_SharylRiley
{
    public partial class StudentScores : Form
    {
        public static Dictionary<string, List<int>> students = new Dictionary<string, List<int>>();
        public static int selected;

        public StudentScores()
        {
            InitializeComponent();
        }
        private void StudentScores_Load_1(object sender, EventArgs e)
        {
            students.Add("Jamie Fraser", new List<int> { 90, 70, 87 });
            students.Add("Claire Fraser ", new List<int> { 100, 99, 94 });
            students.Add("Breanna MacKenzie", new List<int> { 75, 83, 23 });

            AddToListbox();

         
        }
        private void AddToListbox()
        {
            foreach (var student in students)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(student.Key.ToString());
                sb.Append(" - ");
                for (int i = 0; i < student.Value.Count; i++)
                {
                    sb.Append(student.Value[i]);
                    if (i != student.Value.Count - 1)
                    {
                        sb.Append(", ");
                    }
                }
                lstboxStudents.Items.Add(sb);
                lstboxStudents.SetSelected(0, true);
                UpdateInfo();
            }
        }

        private void UpdateInfo()
        {
            try
            {

                txtScoreTotal.Text = students.Values.ElementAt(lstboxStudents.SelectedIndex).Sum().ToString();
                txtScoreCount.Text = students.Values.ElementAt(lstboxStudents.SelectedIndex).Count.ToString();
                txtAverage.Text = Math.Round(students.Values.ElementAt(lstboxStudents.SelectedIndex).Average()).ToString();
            }
            catch (Exception)
            {
                txtScoreTotal.Text = "";
                txtScoreCount.Text = "";
                txtAverage.Text = "";
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form AddNewStudent = new AddNewStudent();
            AddNewStudent.ShowDialog();
            lstboxStudents.Items.Clear();
            AddToListbox();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //selected = lbxScores.SelectedIndex;
            Form UpdateStudentScores = new UpdateStudentScores(students);
           
            selected = lstboxStudents.SelectedIndex;
            if (lstboxStudents.Items.Count > 0)
            {
                UpdateStudentScores.ShowDialog();
            }
           lstboxStudents.Items.Clear();
           AddToListbox();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Delete button
            students.Remove(students.Keys.ElementAt(lstboxStudents.SelectedIndex));
            lstboxStudents.Items.Clear();
            AddToListbox();
            if (students.Count == 0)
            {
                txtScoreTotal.Text = "";
                txtScoreCount.Text = "";
                txtAverage.Text = "";
            }
        }

        private void txtScoreTotal_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtScoreCount_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAverage_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstboxStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateInfo();
           // StudentScores_Load(sender,e);
        }

       
    }
}
