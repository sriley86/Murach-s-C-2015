﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M08_MTPP_5_1_SharylRiley
{
    public partial class AddNewStudent : Form
    {
        Dictionary<string, List<int>> newStudent = new Dictionary<string, List<int>>();
        List<int> scores = new List<int>();
        public AddNewStudent() 
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            txtName.Focus();
        }

        private void txtScore_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtScores_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddScore_Click(object sender, EventArgs e)
        {
           
            try
            {
                if (Int32.Parse(txtScore.Text) >= 0 && Int32.Parse(txtScore.Text) <= 100)
                {
                    scores.Add(Int32.Parse(txtScore.Text));
                }
                else
                {
                    MessageBox.Show("Please enter a score between 0 and 100.", "Invalid score");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid number", "Invalid Entry");
            }
            txtScores.Text = String.Join(", ", scores);
            txtScore.Text = "";
            txtName.Focus();

        }

        private void btnClearScores_Click(object sender, EventArgs e)
        {
            scores.Clear();
            txtScores.Text = "";
            txtScore.Text = "";
            txtName.Focus();
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                StudentScores.students.Add(txtName.Text, scores);
                this.Close();
            }
            else
            {
                MessageBox.Show("Please enter a name", "Empty name field");
                txtName.Focus();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
