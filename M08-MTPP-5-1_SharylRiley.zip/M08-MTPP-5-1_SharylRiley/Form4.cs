﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M08_MTPP_5_1_SharylRiley
{
    public partial class UpdateStudentScores : Form
    {
        public static Dictionary<string, List<int>>tmpStudents;
        BindingSource bs = new BindingSource();
        public static int selected;

        private void UpdateStudentScores_Load(object sender, EventArgs e)
        {

        }



        public UpdateStudentScores(Dictionary<string, List<int>> initStudents)
        {
            InitializeComponent();
           
            tmpStudents = initStudents;
        }
        private void UpdateStudentScores_Activated(object sender, EventArgs e)
        {
            txtName.Text = tmpStudents.Keys.ElementAt(StudentScores.selected);
            bs.DataSource = tmpStudents.Values.ElementAt(StudentScores.selected);
            lstBoxScores.DataSource = bs;
        }
        private void button4_Click(object sender, EventArgs e)
        { //should be btnClearScores
            tmpStudents.Values.ElementAt(StudentScores.selected).RemoveRange(
            0, tmpStudents.Values.ElementAt(StudentScores.selected).Count);
            bs.ResetBindings(false);
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lstBoxScores_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form AddScore = new AddScore();
            AddScore.ShowDialog();
            bs.ResetBindings(false);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            selected = lstBoxScores.SelectedIndex;
            Form updateScore = new UpdateScore();
            updateScore.ShowDialog();
            bs.ResetBindings(false);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            tmpStudents.Values.ElementAt(StudentScores.selected).RemoveAt(lstBoxScores.SelectedIndex);
            bs.ResetBindings(false);
        }


        private void btnOK_Click(object sender, EventArgs e)
        {
            StudentScores.students = tmpStudents;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
